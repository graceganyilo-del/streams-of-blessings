Streams of Blessings PWA package

Upload the CONTENTS of this folder to the ROOT of the Cloudflare Pages GitHub repository (same folder as index.html). Do not upload the ZIP itself as the website. Files: index.html, manifest.json, sw.js, icon-192.png, icon-512.png, apple-touch-icon.png. Commit changes to main and wait for Cloudflare Pages production deployment. Then test /manifest.json and /sw.js on the live domain.
